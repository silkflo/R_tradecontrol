# tradecontrol
project to control trades. calculating profit factor and statistics. experimenting with Reinforcement Learning

## About

This repository was created to help Algorithmic Trader to supervise Trading Robots automatically. Goal is to allow automatic selection of the most profitable systems only. Part of the so called *Lazy Trading Courses* with the main objective to learn Computer and Data Science by building the Algorithmic Trading Systems.

## Learn how to apply that tool in practice

Join *Udemy Course* using this [coupon](https://www.udemy.com/your-trading-control-reinforcement-learning/?couponCode=LAZYTRADE4-10)

## Detail

Read my [blog post](https://vladdsm.github.io/myblog_attempt/topics/lazy%20trading/topics-LazyTrade4-StatisticalControl.html) about the motivation creating this project
